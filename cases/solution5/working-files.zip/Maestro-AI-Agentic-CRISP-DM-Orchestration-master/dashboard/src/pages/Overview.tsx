import { useEffect, useState } from "react";
import { HandoffDownloadLink } from "../components/HandoffDownloadLink";
import { ProgressRail } from "../components/ProgressRail";
import { TokenChart } from "../components/TokenChart";
import { useCommunicationsSummary, useLiveSummary } from "../hooks/useCasePolling";
import { formatDuration } from "../shared/format";
import { useTheme } from "../shared/theme";
import type { LiveSummary, StatusPayload } from "../shared/types";

interface Props {
  caseId: string;
}

function useElapsedMs(live: LiveSummary | undefined): number | null {
  const [now, setNow] = useState(() => Date.now());

  useEffect(() => {
    if (!live || live.halted || live.trace.ended_at) return;
    const id = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(id);
  }, [live]);

  if (!live?.trace.started_at) return live?.elapsed_ms ?? null;
  const start = new Date(live.trace.started_at).getTime();
  const end = live.trace.ended_at
    ? new Date(live.trace.ended_at).getTime()
    : now;
  return Math.max(0, end - start);
}

function Chip({
  label,
  value,
  dot,
}: {
  label: string;
  value: string;
  dot?: string;
}) {
  return (
    <span className="inline-flex items-center gap-2 rounded-lg border border-surface-border bg-surface px-3 py-1.5 text-xs">
      {dot && <span className={`h-2 w-2 rounded-full ${dot}`} />}
      <span className="font-semibold text-slate-400">{label}</span>
      <span className="font-medium text-slate-200">{value}</span>
    </span>
  );
}

function statusFromLive(live: LiveSummary): StatusPayload {
  return {
    updated_at: live.updated_at,
    case_id: live.case_id,
    phase: live.phase,
    phase_name: live.phase_name,
    substep: live.substep,
    substep_name: live.substep_name,
    activity: live.activity,
    completed_substeps: live.progress.completed_substeps,
    total_substeps: live.progress.total_substeps,
    token_spend: live.token_spend,
    halted: live.halted,
    halt_reason: live.halt_reason,
    workflow_complete: live.workflow_complete,
    ml_success: live.ml_success,
    ml_deficits: live.ml_deficits,
    artifact_dir: "",
    trace_dir: "",
  };
}

export function Overview({ caseId }: Props) {
  const { clean } = useTheme();
  const { data: live } = useLiveSummary(caseId);
  const { data: summary } = useCommunicationsSummary(caseId);

  const elapsedMs = useElapsedMs(live);
  const isRunning = live != null && !live.halted && live.trace.ended_at == null;
  const status = live ? statusFromLive(live) : undefined;

  const runStatus = live?.halted
    ? { label: "Halted", dot: "bg-status-halted", active: false }
    : live?.workflow_complete || live?.trace.ended_at
    ? { label: "Complete", dot: "bg-status-complete", active: false }
    : { label: "Running", dot: "bg-status-running", active: true };

  return (
    <div className="space-y-6">
      {live && (
        <div className="flex flex-wrap items-center gap-x-4 gap-y-2">
          <span className="flex items-center gap-2 rounded-full border border-surface-border bg-surface px-3 py-1 text-sm font-semibold">
            <span
              className={`h-2.5 w-2.5 rounded-full ${runStatus.dot} ${
                runStatus.active ? "node-active" : ""
              }`}
            />
            {runStatus.label}
          </span>
          <p className="text-sm font-medium text-slate-400">
            Phase {live.phase} — {live.phase_name} ·{" "}
            {live.progress.completed_substeps}/{live.progress.total_substeps}{" "}
            substeps
          </p>
        </div>
      )}

      <div className="grid gap-6 lg:grid-cols-2">
      <section className="rounded-2xl border border-surface-border bg-surface-raised p-5 space-y-4 glow-card">
        <h2 className="text-lg font-bold">{clean("📊 Progress")}</h2>
        {elapsedMs != null && (
          <p className="text-sm">
            <span className="text-slate-400">Elapsed:</span>{" "}
            <span className="font-mono text-slate-100">
              {formatDuration(elapsedMs)}
            </span>
            {live?.trace.started_at && (
              <span className="text-slate-500 ml-2">
                (since {new Date(live.trace.started_at).toLocaleString()})
              </span>
            )}
          </p>
        )}
        <ProgressRail status={status} />
        {live && (
          <div className="space-y-4">
            <div className="flex flex-wrap gap-2">
              <Chip label="Substep" value={`${live.substep} · ${live.substep_name}`} />
              {live.ml_success != null && (
                <Chip
                  dot={live.ml_success ? "bg-status-complete" : "bg-amber-400"}
                  label="ML outcome"
                  value={live.ml_success ? "success" : "needs another pass"}
                />
              )}
            </div>
            {(live.halt_reason || (live.ml_deficits?.length ?? 0) > 0) && (
              <p className="text-sm leading-relaxed text-slate-400">
                {live.halt_reason ?? live.ml_deficits?.join("; ")}
              </p>
            )}
            <HandoffDownloadLink
              caseId={caseId}
              show={Boolean(live.halted || live.workflow_complete)}
              className="pt-3 border-t border-surface-border/60"
            />
          </div>
        )}
      </section>

      <section className="rounded-2xl border border-surface-border bg-surface-raised p-5 glow-card">
        <h2 className="text-lg font-bold mb-4">{clean("🪙 Token spend")}</h2>
        <TokenChart
          summary={summary}
          tokenSpend={live?.token_spend}
          tokenBudget={live?.token_budget}
        />
      </section>

      <section className="rounded-2xl border border-surface-border bg-surface-raised p-5 lg:col-span-2 glow-card">
        <h2 className="text-lg font-bold mb-2">{clean("💬 Activity")}</h2>
        <p className="text-sm text-slate-400">
          {live?.activity ?? clean("Waiting for status… 🕰️")}
        </p>
        {live?.in_flight && (
          <p className="text-sm text-yellow-400/90 mt-2">
            In-flight LLM:{" "}
            <span className="font-mono">{live.in_flight.communication_id}</span>{" "}
            ({live.in_flight.agent}, substep {live.in_flight.substep})
          </p>
        )}
        {live?.last_comm && (
          <p className="text-sm text-slate-500 mt-2">
            {clean("🦄")} Last LLM turn:{" "}
            <span className="font-mono text-accent-muted">{live.last_comm.id}</span>{" "}
            ({live.last_comm.agent}, {live.last_comm.tokens ?? "?"} tokens)
          </p>
        )}
        {summary && summary.parse_failures > 0 && (
          <p className="text-sm text-status-halted font-semibold mt-2">
            {clean("😬")} {summary.parse_failures} parse failure(s) detected
          </p>
        )}
        {isRunning && (
          <p className="text-xs text-slate-600 mt-3">
            Polling live summary only (~{live ? "<10" : "?"} KB/tick). Open
            Communications for full LLM turns.
          </p>
        )}
      </section>
      </div>
    </div>
  );
}
